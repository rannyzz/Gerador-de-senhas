const tamanhosenha = document.getElementById('tamanho_senha');
        const checkboxMaiuscula = document.getElementById('maiuscula');
        const checkboxMinuscula = document.getElementById('minuscula');
        const checkboxNumeros = document.getElementById('numeros');
        const checkboxSimbolos = document.getElementById('simbolos');

        const maiuscula = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        const minuscula = "abcdefghijklmnopqrstuvwxyz";
        const numeros = "0123456789";
        const simbolos = "!@#$%^&*";

        const camposenha = document.getElementById('senha_gerada');

        function gerarSenha() {
            let tamanho = parseInt(tamanhosenha.value);
            let caracteres = "";
            let senha = "";

            if (checkboxMaiuscula.checked) {
                caracteres += maiuscula;
            }

            if (checkboxMinuscula.checked) {
                caracteres += minuscula;
            }

            if (checkboxNumeros.checked) {
                caracteres += numeros;
            }

            if (checkboxSimbolos.checked) {
                caracteres += simbolos;
            }

            if (caracteres === "") {
                camposenha.innerText = "Selecione pelo menos um tipo de caractere.";
                return;
            }

            if (isNaN(tamanho) || tamanho <= 0) {
                camposenha.innerText = "Digite um tamanho válido.";
                return;
            }

            for (let i = 0; i < tamanho; i++) {
                let aleatorio = Math.floor(Math.random() * caracteres.length);
                senha += caracteres[aleatorio];
            }

            camposenha.innerText = senha;
        }